// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




void
n_paint_hamburger_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{
//return;

	switch( msg ) {


	case WM_LBUTTONDOWN :
	{

		if ( n_paint_pen_start ) { break; }


		s32 x,y,sx,sy; n_paint_hamburger_get( &x,&y,&sx,&sy );

		if ( n_win_is_hovered_offset( hwnd, x,y,sx,sy ) )
		{
			n_paint_hamburger_is_started = true;
		} else {
			n_paint_hamburger_onoff = false;
		}

	}
	break;

	case WM_LBUTTONUP :
	{

		if ( n_paint_pen_start ) { break; }

		if ( n_paint_hamburger_is_started == false ) { break; }
		n_paint_hamburger_is_started = false;


		s32 x,y,sx,sy; n_paint_hamburger_get( &x,&y,&sx,&sy );

		if ( n_win_is_hovered_offset( hwnd, x,y,sx,sy ) )
		{
			if ( n_paint_hamburger_onoff == false )
			{
				n_paint_hamburger_onoff = true;
				n_paint_refresh_client();

				n_win_simplemenu_show( &n_paint_simplemenu, hwnd );
			} else {
				n_paint_hamburger_onoff = false;
				n_paint_refresh_client();
			}
		} else {
			n_paint_hamburger_onoff = false;
			n_paint_refresh_client();
		}

	}
	break;

	case WM_MOUSELEAVE :
	case WM_MOUSEMOVE :
	{
//break;
		if ( n_paint_pen_start ) { break; }


//n_win_hwndprintf_literal( hwnd, " %d %d ", n_paint_hamburger_onoff, n_paint_hamburger_is_hovered );

		if ( msg == WM_MOUSEMOVE ) { n_win_on_mousemove( hwnd ); }

		s32 x,y,sx,sy; n_paint_hamburger_get( &x,&y,&sx,&sy );

		if ( n_win_is_hovered_offset( hwnd, x,y,sx,sy ) )
		{
			if ( n_paint_hamburger_is_hovered == false )
			{
				n_paint_hamburger_is_hovered = true;
				n_paint_refresh_client();
			}
		} else {
			if ( n_paint_hamburger_is_hovered != false )
			{
				if ( false == IsWindow( n_paint_simplemenu.hwnd ) )
				{
					n_paint_hamburger_is_hovered = false;
					n_paint_refresh_client();
				}
			}
		}

	}
	break;

	case WM_COMMAND : 
	{

		HWND h = (HWND) lparam;

		if ( h == n_paint_simplemenu.hwnd )
		{
			s32 x,y,sx,sy; n_paint_hamburger_get( &x,&y,&sx,&sy );

			if ( false == n_win_is_hovered_offset( hwnd, x,y,sx,sy ) )
			{
				n_paint_hamburger_onoff = false;
			}
		}

	}
	break;


	case WM_KILLFOCUS :

		n_paint_hamburger_onoff = false;

	break;


	} // switch


	return;
}


