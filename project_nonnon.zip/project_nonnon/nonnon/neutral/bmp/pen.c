// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_NEUTRAL_BMP_PEN
#define _H_NONNON_NEUTRAL_BMP_PEN




#include "../bmp.c"




typedef void (*n_bmp_pen_callback)( s32 fx, s32 fy, double blend );




void
n_bmp_pen_bresenham( s32 fx, s32 fy, s32 tx, s32 ty, double blend, n_bmp_pen_callback callback )
{

	// Bresenham's line algorithm


	if ( ( fx == tx )&&( fy == ty ) )
	{
		callback( fx,fy, blend );
		return;
	}


	double step = (double) abs( fy - ty ) / abs( fx - tx );
	double d    = 0;
	while( 1 )
	{

		// [!] : the first pixel will be skipped


		// [!] : don't do "else" : avoid zig-zag

		if ( d <  1 )
		{
			d += step;
			if ( fx > tx ) { fx--; } else
			if ( fx < tx ) { fx++; }
		}
		if ( d >= 1 )
		{
			d -= 1;
			if ( fy > ty ) { fy--; } else
			if ( fy < ty ) { fy++; }
		}


		callback( fx,fy, blend );


		if ( ( fx == tx )&&( fy == ty ) ) { break; }

//n_win_hwndprintf_literal( hwnd_main, "%f : %f", d, step );

	}


	return;
}

void
n_bmp_pen_wu( double x1, double y1, double x2, double y2, double blend, n_bmp_pen_callback callback )
{

	// Xiaolin Wu's line algorithm


	//double start_x = x1;
	//double start_y = y1;


	double dx = x2 - x1;
	double dy = y2 - y1;


	s32 abs_dx = (s32) fabs( dx );
	s32 abs_dy = (s32) fabs( dy );

	if (
		( abs_dx == abs_dy )
		||
		( x1 == x2 )||( y1 == y2 )
	)
	{
//color = n_bmp_rgb( 255, 200, 0 );
//blend = 1;

		// [!] : this will be a straight line

		n_bmp_pen_bresenham( (s32) x1, (s32) y1, (s32) x2, (s32) y2, blend, callback );

		return;

	}


	// [Mechanism]
	//
	//	continuous line needs 0.0 to 1.0 for "step"
	//	swap temporarily when slope is steep
	//
	//	"step" may have minus value

	double step_x = 0;
	double step_y = 0;

	if ( abs_dx == abs_dy )
	{
		if ( dx > 0 ) { step_x = 1; } else { step_x = -1; }
		if ( dy > 0 ) { step_y = 1; } else { step_y = -1; }
	} else
	if ( abs_dy < abs_dx )
	{
		step_y = dy / abs_dx;
		if ( dx > 0 ) { step_x = 1; } else { step_x = -1; }
	} else
	if ( abs_dx < abs_dy )
	{
		step_x = dx / abs_dy;
		if ( dy > 0 ) { step_y = 1; } else { step_y = -1; }
	}


	double x = x1;
	double y = y1;
	while( 1 )
	{

		double blend1 = blend;
		double blend2 = blend;

		if ( x == x1 )
		{
			blend1 *= 0.5;
			blend2 *= 0.0;
		} else {
			blend1 *= 1 - ( y - trunc( y ) );
			blend2 *=     ( y - trunc( y ) );
		}


		double xx1 = trunc( x );
		double yy1 = trunc( y );
		double xx2 = trunc( x );
		double yy2 = trunc( y ) + 1;

		if ( x != x1 )
		{
			callback( (s32) xx1, (s32) yy1, blend1 );
			callback( (s32) xx2, (s32) yy2, blend2 );
		}

//if ( ( start_x == xx1 )&&( start_y == yy1 ) ) { callback( xx1, yy1, 1.0 ); }
//if ( ( start_x == xx2 )&&( start_y == yy2 ) ) { callback( xx2, yy2, 1.0 ); }


//if ( xx1 == x2 ) { break; }

		if ( abs_dx == abs_dy )
		{
			if ( ( xx1 == x2 )&&( yy1 == y2 ) ) { break; }
		} else
		if ( abs_dy < abs_dx )
		{
			if ( xx1 == x2 ) { break; }
		} else
		if ( abs_dx < abs_dy )
		{
			if ( yy1 == y2 ) { break; }
		}

		x += step_x;
		y += step_y;

	}


	return;
}


#endif //_H_NONNON_NEUTRAL_BMP_PEN

