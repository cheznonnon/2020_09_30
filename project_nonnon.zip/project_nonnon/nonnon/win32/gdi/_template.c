// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// Template : copy and paste then modify this
/*
void
n_gdi_template( n_bmp *bmp )
{

	n_gdi gdi; n_gdi_zero( &gdi );


	gdi.sx                  = 0;
	gdi.sy                  = 0;
	gdi.scale               = N_GDI_SCALE_AUTO;
	gdi.style               = N_GDI_DEFAULT;
	gdi.layout              = N_GDI_LAYOUT_HORIZONTAL;
	gdi.align               = N_GDI_ALIGN_CENTER;

	gdi.base                = n_posix_literal( "" );
	gdi.base_index          = 0;
	gdi.base_color_bg       = n_bmp_rgb( 255,255,255 );
	gdi.base_color_fg       = n_bmp_rgb( 255,255,255 );
	gdi.base_style          = N_GDI_BASE_SOLID;
	gdi.base_unit           = 0;

	gdi.frame_style         = N_GDI_FRAME_NOFRAME;
	gdi.frame_round         = 0;

	gdi.icon                = n_posix_literal( "" );
	gdi.icon_index          = 0;
	gdi.icon_bpp            = 0;
	gdi.icon_rsrc           = 0;
	gdi.icon_style          = N_GDI_ICON_DEFAULT;
	gdi.icon_color_shadow   = n_bmp_white_invisible;
	gdi.icon_color_shadow   = n_bmp_rgb(  10, 10, 10 );
	gdi.icon_color_contour  = n_bmp_rgb(  10, 10, 10 );
	gdi.icon_color_sink_tl  = n_bmp_rgb(  10, 10, 10 );
	gdi.icon_color_sink_br  = n_bmp_rgb(  10, 10, 10 );
	gdi.icon_fxsize1        = 0;
	gdi.icon_fxsize2        = 0;
	gdi.icon_sx             = 0;
	gdi.icon_sy             = 0;

	gdi.text                = n_posix_literal( "" );
	gdi.text_font           = n_posix_literal( "" );
	gdi.text_size           = 16;
	gdi.text_style          = N_GDI_TEXT_DEFAULT;
	gdi.text_color_main     = n_bmp_rgb( 255,255,255 );
	gdi.text_color_gradient = n_bmp_rgb( 255,255,255 );
	gdi.text_color_shadow   = n_bmp_rgb(  10, 10, 10 );
	gdi.text_color_contour  = n_bmp_rgb(  10, 10, 10 );
	gdi.text_color_sink_tl  = n_bmp_rgb(  10, 10, 10 );
	gdi.text_color_sink_br  = n_bmp_rgb(  10, 10, 10 );
	gdi.text_fxsize1        = 0;
	gdi.text_fxsize2        = 0;


	n_bmp_free( bmp );
	n_gdi_bmp( &gdi, bmp );


	return;
}
*/

