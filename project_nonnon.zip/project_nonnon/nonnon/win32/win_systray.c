// nmixer
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html



// [!] : <shellapi.h>


// [!] : Size : classic scheme
//
//	tray icon == title bar font == clock font
//
//	+ icon will be ugly when size has changed
//	+ you need to do n_win_systray_icon_change() to fix




#ifndef _H_NONNON_WIN32_WIN_SYSTRAY
#define _H_NONNON_WIN32_WIN_SYSTRAY




#include "../neutral/posix.c"


#include "./win/icon.c"




// [!] : don't use WM_USER

#define N_WIN_SYSTRAY_MESSAGE WM_APP




#define n_win_systray_init_literal( a,b,c,d,e,f ) n_win_systray_init( a, b, c, n_posix_literal( d ), n_posix_literal( e ), f )

void
n_win_systray_init
(
	      NOTIFYICONDATA *nid,
	                HWND  hwnd,
	                UINT  id,
	        n_posix_char *icon,
	const   n_posix_char *tip,
	                bool  draw
)
{

	if ( nid == NULL ) { return; }


	// [Mechanism]
	//
	//	icon : icon resource name


	HINSTANCE hinst = GetModuleHandle( NULL );


	nid->cbSize           = sizeof( NOTIFYICONDATA );
	nid->hWnd             = hwnd;
	nid->uID              = id;
	nid->uFlags           = NIF_ICON | NIF_MESSAGE | NIF_TIP;
	nid->uCallbackMessage = N_WIN_SYSTRAY_MESSAGE;
	nid->hIcon            = LoadImage( hinst, icon, IMAGE_ICON, 0,0, LR_DEFAULTCOLOR );


	// [!] : WinXP : notify area manager uses this data

	if ( 64 > n_posix_strlen( tip ) )
	{
		n_posix_sprintf_literal( nid->szTip, "%s", tip );
	}


	if ( draw )
	{
		Shell_NotifyIcon( NIM_ADD, nid );
	}


	return;
}

void
n_win_systray_exit( NOTIFYICONDATA *nid )
{

	if ( nid == NULL ) { return; }


	Shell_NotifyIcon( NIM_DELETE, nid );


	// [Needed] : prevent handle leak

	n_win_icon_exit( nid->hIcon );


	ZeroMemory( nid, sizeof( NOTIFYICONDATA ) );


	return;
}

HICON
n_win_systray_icon_load( const n_posix_char *iconname, const int *supported, int index )
{

	// [Mechanism]
	//
	//	iconname  : resource name of a multi-icon
	//	supported : int supported[] = { 16, 24, 32, 0 };
	//	index     : fallback : for ExtractIcon()
	//
	//	the returned HICON needs n_win_icon_exit()


	s32 fsx,fsy, tsx,tsy;

	fsx = tsx = GetSystemMetrics( SM_CXSMICON );
	fsy = tsy = GetSystemMetrics( SM_CYSMICON );


	if ( supported != NULL )
	{

		int i = 0;
		while( 1 )
		{

			fsx = fsy = supported[ i ];

			i++;
			if ( supported[ i ] >  tsx ) { break; } else
			if ( supported[ i ] ==   0 ) { break; }
		}

	}

//n_posix_debug_literal( "%d:%d", fsx,fsy );

	HICON hicon = NULL;

	n_bmp b; n_bmp_zero( &b );
	n_bmp m; n_bmp_zero( &m );

	if ( n_win_icon_load_from_resource( iconname, index, fsx, 32, &b, &m, NULL, NULL, n_bmp_trans, false ) )
	{

		const HINSTANCE hinst = GetModuleHandle( NULL );


		// [!] : Vista or later : LR_SHARED + DestroyWindow() only prevents GDI handle leak

		UINT lr = LR_DEFAULTCOLOR | LR_SHARED;
		hicon = LoadImage( hinst, iconname, IMAGE_ICON, fsx,fsy, lr );

		if ( hicon == NULL )
		{
			hicon = ExtractIcon( hinst, iconname, index );
		}
		if ( hicon == NULL ) { return NULL; }


		// [!] : for performance

		if ( ( fsx == tsx )&&( fsy == tsy ) )
		{
			return hicon;
		}


		n_win_icon_hicon2bmp( hicon, fsx,fsy, &b, &m );

	}


	{

		int ratio = tsx / fsx;

		n_bmp_scaler_big( &b, ratio );
		n_bmp_scaler_big( &m, ratio );

		n_win_icon_resizer( &b, tsx,tsy, n_bmp_black );
		n_win_icon_resizer( &m, tsx,tsy, n_bmp_white );

	}


	n_win_icon_exit( hicon );
	hicon = n_win_icon_bmp2hicon( &b, &m );


	n_bmp_free_fast( &b );
	n_bmp_free_fast( &m );


	return hicon;
}

void
n_win_systray_icon_change( NOTIFYICONDATA *nid, const n_posix_char *iconname, int index, const int *supported )
{

	if ( nid == NULL ) { return; }


	n_win_icon_exit( nid->hIcon );

	nid->hIcon = n_win_systray_icon_load( iconname, supported, index );

	Shell_NotifyIcon( NIM_MODIFY, nid );


	return;
}


#endif // _H_NONNON_WIN32_WIN_SYSTRAY

