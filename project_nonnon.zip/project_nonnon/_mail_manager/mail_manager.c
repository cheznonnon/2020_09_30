// Nonnon Mail Manager
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/project/define_unicode.c"




#include "../nonnon/neutral/ini.c"

#include "../nonnon/win32/mapi.c"
#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_smallbutton.c"


#include "../nonnon/project/macro.c"




#define N_MAILMANAGER_INI_NAME n_posix_literal( "mail_manager.ini" )
#define N_MAILMANAGER_INI_SECT n_posix_literal( "[Mail Manager]"   )


#include "./listview.c"
#include "./popup.c"




#define H_LISTVIEW hgui[ 0 ]
#define H_SB_FIND  hgui[ 1 ]
#define H_SB_RESET hgui[ 2 ]
#define H_INPUT    hgui[ 3 ]
#define H_BUTTON   hgui[ 4 ]
#define GUI_MAX          5

static HWND hgui[ GUI_MAX ];



static n_posix_char *cmdline = NULL;


static n_win_smallbutton smlbtn_find;
static n_win_smallbutton smlbtn_reset;




void
n_mailmanager_go( HWND hgui )
{

	n_ini ini; n_ini_zero( &ini ); n_ini_load( &ini, N_MAILMANAGER_INI_NAME );


	const n_posix_char *lval = n_posix_literal( "filter" );

	n_posix_char *filter = n_ini_value_str_new( &ini, N_MAILMANAGER_INI_SECT, lval, N_STRING_EMPTY );


	n_ini_free( &ini );


	int sy = n_win_listview_item_count( hgui );
	int  y = 0;
	while( 1 )
	{

		if ( y >= sy ) { break; }


		if ( n_win_listview_item_is_checked( hgui, y ) )
		{

			n_posix_char * address = n_string_carboncopy( n_posix_literal( "mail@mail.com" ) );
			n_posix_char *   title = n_string_carboncopy( n_posix_literal( "" ) );
			n_posix_char *contents = n_string_new( n_win_listview_item_debug_cch( hgui, y, filter ) );

			n_posix_sprintf_literal( address, "mail@mail.com" );
			//n_posix_sprintf_literal(   title, "Title" );
			n_win_listview_item_debug( hgui, y, contents, filter );

			n_mapi_send( address, title, contents );

			n_string_free(  address );
			n_string_free(    title );
			n_string_free( contents );

		}


		y++;

	}


	return;
}

void
n_mailmanager_search( void )
{

	n_posix_char str[ N_WIN_LISTVIEW_CCH ]; n_win_text_get( H_INPUT, str, N_WIN_LISTVIEW_CCH - 1 );

	n_win_listview_item_filter( H_LISTVIEW, str );


	return;
}

LRESULT CALLBACK
n_mailmanager_on_keydown( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	if ( wparam == VK_RETURN )
	{

		n_mailmanager_search();

		return true;

	}


	return false;
}

void
n_mailmanager_resize( HWND hwnd )
{

	const bool redraw = true;


	n_win w; n_win_set( hwnd, &w, -1,-1, n_project_n_win_set() );


	s32 ctl,ico,m; n_win_stdsize( hwnd, &ctl, &ico, &m );

	{

		s32 sx = ( ctl * 12 );
		s32 sy = ( ctl *  1 );
		s32 x  = ( w.csx - m ) - sx;
		s32 y  = ( ico - ctl ) / 2;

		n_win_move( H_INPUT, x,y, sx,sy, redraw );

		n_win_smallbutton_embed( &smlbtn_find,  H_INPUT, 0, redraw );
		n_win_smallbutton_embed( &smlbtn_reset, H_INPUT, 1, redraw );

	}


	n_win_move_simple( H_LISTVIEW, 0,         ico, w.csx, w.csy - ctl - ico, redraw );
	n_win_move_simple( H_BUTTON,   0, w.csy - ctl, w.csx,               ctl, redraw );


	return;
}

void
n_mailmanager_load( n_posix_char *cmdline )
{

	bool ret = n_listview_load( H_LISTVIEW, cmdline );
	if ( ret )
	{
		n_string_free( cmdline );
		cmdline = n_string_carboncopy( n_posix_literal( "default.csv" ) );
		n_listview_load( H_LISTVIEW, cmdline );
	}


	return;
}

LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_CREATE :


		// Global

		n_win_exedir2curdir();


		// Window

		n_win_init_literal( hwnd, "Mail Manager", "A_MAINICON", "" );

		n_project_window_resizable( hwnd );

		{

			s32 desktop_sx, desktop_sy;
			n_win_desktop_size( &desktop_sx, &desktop_sy );

			s32 sx = (double) desktop_sx * 0.7;
			s32 sy = (double) desktop_sy * 0.7;

			n_win_set( hwnd, NULL, sx,sy, N_WIN_SET_CENTERING );

		}


		// Init

		n_listview_gui( hwnd, &H_LISTVIEW );

		{
			n_posix_char *cmdline = n_win_commandline_new();
			n_mailmanager_load( cmdline );
			n_string_path_free( cmdline );
		}

		n_win_gui_literal( hwnd, CANVAS,                  "", &H_SB_FIND  );
		n_win_gui_literal( hwnd, CANVAS,                  "", &H_SB_RESET );
		n_win_gui_literal( hwnd,  INPUT,                  "", &H_INPUT    );
		n_win_gui        ( hwnd,   FBTN, n_project_string_go, &H_BUTTON   );

		n_win_smallbutton_init( &smlbtn_find,  H_SB_FIND,  1 );
		n_win_smallbutton_init( &smlbtn_reset, H_SB_RESET, 2 );

		n_win_property_init_literal( H_INPUT, "WM_KEYDOWN", (int) n_mailmanager_on_keydown );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_DROPFILES :
	{

		n_posix_char *cmdline = n_win_dropfiles_multiple_new( hwnd, wparam );

		n_win_listview_item_reset( H_LISTVIEW );
		n_mailmanager_load( cmdline );

	}
	break;


	case WM_SIZE :

		n_mailmanager_resize( hwnd );

	break;


	case WM_KEYDOWN :

		if ( wparam == VK_F1 )
		{

			n_string_free( clipboard );
			clipboard = n_string_new( n_win_listview_item_debug_cch_literal( H_LISTVIEW, -1, "all" ) );

			n_win_listview_item_debug_literal( H_LISTVIEW, -1, clipboard, "all" );

			n_win_gui( hwnd, WINDOW, n_mailmanager_popup_wndproc, &hpopup );

		} else
		if ( wparam == VK_F2 )
		{

			n_win_listview_item_del( H_LISTVIEW, 1 );

		} else
		if ( wparam == VK_F3 )
		{

			n_win_listview_item_reset( H_LISTVIEW );

			n_posix_char *cmdline = n_win_commandline_new();
			n_mailmanager_load( cmdline );
			n_string_path_free( cmdline );

		} else
		if ( wparam == VK_F4 )
		{

			n_win_listview_item_filter( H_LISTVIEW, n_posix_literal( "test" ) );

		} else
		if ( wparam == VK_ESCAPE )
		{

			n_win_listview_item_reset( H_LISTVIEW );

		}// else

	break;


	case WM_COMMAND :

		if ( (HWND) lparam == H_SB_FIND )
		{

			if ( n_win_smallbutton_is_clicked( wparam ) )
			{
				n_mailmanager_search();
			}

		} else
		if ( (HWND) lparam == H_SB_RESET )
		{

			if ( n_win_smallbutton_is_clicked( wparam ) )
			{
				n_win_listview_item_reset( H_LISTVIEW );

				n_posix_char *cmdline = n_win_commandline_new();
				n_mailmanager_load( cmdline );
				n_string_path_free( cmdline );
			}

		} else
		if ( (HWND) lparam == H_BUTTON )
		{

			n_mailmanager_go( H_LISTVIEW );

		}// else

	break;


	case WM_NOTIFY :
	{

		NMHDR *n = (NMHDR*) lparam;
		if ( n == NULL ) { break; }

		switch( n->code ) {

			case NM_DBLCLK :
			{

				n_string_free( clipboard );
				clipboard = n_string_new( n_win_listview_item_debug_cch_literal( H_LISTVIEW, -1, "all" ) );

				n_win_listview_item_debug_literal( H_LISTVIEW, -1, clipboard, "all" );
//n_posix_debug_literal( "%s", str );

				n_win_gui( hwnd, WINDOW, n_mailmanager_popup_wndproc, &hpopup );

			}
			break;

			case LVN_COLUMNCLICK :
			{

				NMLISTVIEW *nmlv = (NMLISTVIEW*) lparam;
				if ( nmlv == NULL ) { break; }

				n_win_listview_item_sort( H_LISTVIEW, nmlv->iSubItem );

			}
			break;

			case n_HDN_ITEMSTATEICONCLICK :
			{

				static bool toggle = false;
				if ( toggle ) { toggle = false; } else { toggle = true; }

				n_win_listview_header_check( H_LISTVIEW, toggle );

			}
			break;

		} // switch

	}
	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );


		n_string_free( cmdline   );
		n_string_free( clipboard );

		n_win_smallbutton_exit( &smlbtn_find  );
		n_win_smallbutton_exit( &smlbtn_reset );

		n_win_property_exit_literal( H_INPUT, "WM_KEYDOWN" );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_smallbutton_proc( hwnd, msg, wparam, lparam, &smlbtn_find  );
	n_win_smallbutton_proc( hwnd, msg, wparam, lparam, &smlbtn_reset );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}


